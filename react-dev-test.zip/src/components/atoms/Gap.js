const Gap = ({ width, height }) => {
  return <div style={{ width: width, height: height }}></div>;
};

export default Gap;
